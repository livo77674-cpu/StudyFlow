// ПУТЬ: com/studyflow/app/ui/theme/Theme.kt

package com.studyflow.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.studyflow.app.domain.model.CognitiveTier

/**
 * Палитра строгой тёмной темы StudyFlow без визуального шума.
 */
object StudyFlowColors {
    // Базовые фоны и поверхности
    val Background = Color(0xFF0D0F12)
    val Surface = Color(0xFF161A20)
    val SurfaceElevated = Color(0xFF1D232B)
    val SurfaceStroke = Color(0xFF28303B)

    // Текст
    val TextPrimary = Color(0xFFF3F5F7)
    val TextSecondary = Color(0xFF9AA4B2)
    val TextMuted = Color(0xFF677180)

    // Фокусные оранжевые акценты
    val PrimaryOrange = Color(0xFFFF6B00)
    val PrimaryOrangeLight = Color(0xFFFF8533)
    val PrimaryOrangeContainer = Color(0xFF2E1B0E)

    // Цвета когнитивных эшелонов
    val Tier1Color = Color(0xFFFF6B00)
    val Tier1Container = Color(0xFF2D190C)

    val Tier2Color = Color(0xFFFFB020)
    val Tier2Container = Color(0xFF2B2210)

    val Tier3Color = Color(0xFF5FA8D3)
    val Tier3Container = Color(0xFF132430)

    // Спокойные оттенки для фазы перерыва (BREAK)
    val BreakAccent = Color(0xFF4ECDC4)
    val BreakAccentSoft = Color(0xFF7ADAD3)
    val BreakContainer = Color(0xFF112627)

    // Статусы и предупреждения
    val Success = Color(0xFF34C759)
    val Warning = Color(0xFFFFA726)
    val WarningContainer = Color(0xFF2B2112)
    val Danger = Color(0xFFEF5350)
    val DangerContainer = Color(0xFF2D1416)
}

/**
 * Возвращает акцентный цвет для заданного когнитивного эшелона.
 */
fun CognitiveTier.accentColor(): Color = when (this) {
    CognitiveTier.TIER_1 -> StudyFlowColors.Tier1Color
    CognitiveTier.TIER_2 -> StudyFlowColors.Tier2Color
    CognitiveTier.TIER_3 -> StudyFlowColors.Tier3Color
}

/**
 * Возвращает приглушённый цвет подложки для бейджей и карточек эшелона.
 */
fun CognitiveTier.containerColor(): Color = when (this) {
    CognitiveTier.TIER_1 -> StudyFlowColors.Tier1Container
    CognitiveTier.TIER_2 -> StudyFlowColors.Tier2Container
    CognitiveTier.TIER_3 -> StudyFlowColors.Tier3Container
}

private val StudyFlowDarkColorScheme = darkColorScheme(
    primary = StudyFlowColors.PrimaryOrange,
    onPrimary = Color(0xFF140A02),
    primaryContainer = StudyFlowColors.PrimaryOrangeContainer,
    onPrimaryContainer = StudyFlowColors.PrimaryOrangeLight,
    secondary = StudyFlowColors.PrimaryOrangeLight,
    onSecondary = Color(0xFF140A02),
    secondaryContainer = StudyFlowColors.SurfaceElevated,
    onSecondaryContainer = StudyFlowColors.TextPrimary,
    tertiary = StudyFlowColors.BreakAccent,
    onTertiary = Color(0xFF061A1A),
    tertiaryContainer = StudyFlowColors.BreakContainer,
    onTertiaryContainer = StudyFlowColors.BreakAccentSoft,
    background = StudyFlowColors.Background,
    onBackground = StudyFlowColors.TextPrimary,
    surface = StudyFlowColors.Surface,
    onSurface = StudyFlowColors.TextPrimary,
    surfaceVariant = StudyFlowColors.SurfaceElevated,
    onSurfaceVariant = StudyFlowColors.TextSecondary,
    outline = StudyFlowColors.SurfaceStroke,
    outlineVariant = Color(0xFF202630),
    error = StudyFlowColors.Danger,
    onError = Color(0xFF1A0707),
    errorContainer = StudyFlowColors.DangerContainer,
    onErrorContainer = Color(0xFFFFB4AB)
)

private val StudyFlowTypography = Typography(
    displayLarge = TextStyle(
        fontWeight = FontWeight.Bold,
        fontSize = 56.sp,
        lineHeight = 62.sp,
        letterSpacing = (-1.5).sp
    ),
    headlineMedium = TextStyle(
        fontWeight = FontWeight.SemiBold,
        fontSize = 24.sp,
        lineHeight = 30.sp,
        letterSpacing = (-0.3).sp
    ),
    headlineSmall = TextStyle(
        fontWeight = FontWeight.SemiBold,
        fontSize = 20.sp,
        lineHeight = 26.sp
    ),
    titleLarge = TextStyle(
        fontWeight = FontWeight.SemiBold,
        fontSize = 18.sp,
        lineHeight = 24.sp
    ),
    titleMedium = TextStyle(
        fontWeight = FontWeight.Medium,
        fontSize = 15.sp,
        lineHeight = 21.sp
    ),
    bodyLarge = TextStyle(
        fontWeight = FontWeight.Normal,
        fontSize = 15.sp,
        lineHeight = 22.sp
    ),
    bodyMedium = TextStyle(
        fontWeight = FontWeight.Normal,
        fontSize = 13.sp,
        lineHeight = 19.sp
    ),
    labelLarge = TextStyle(
        fontWeight = FontWeight.SemiBold,
        fontSize = 13.sp,
        lineHeight = 18.sp,
        letterSpacing = 0.2.sp
    ),
    labelMedium = TextStyle(
        fontWeight = FontWeight.Medium,
        fontSize = 12.sp,
        lineHeight = 16.sp,
        letterSpacing = 0.3.sp
    ),
    labelSmall = TextStyle(
        fontWeight = FontWeight.Medium,
        fontSize = 11.sp,
        lineHeight = 14.sp,
        letterSpacing = 0.4.sp
    )
)

@Composable
fun StudyFlowTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = StudyFlowDarkColorScheme,
        typography = StudyFlowTypography,
        content = content
    )
}
