// ПУТЬ: com/studyflow/app/service/TimerForegroundService.kt

package com.studyflow.app.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.SystemClock
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.studyflow.app.data.local.AppDatabase
import com.studyflow.app.domain.engine.RuleEngine
import com.studyflow.app.domain.model.CognitiveTier
import com.studyflow.app.domain.model.TimerPhase
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale
import kotlin.math.ceil
import kotlin.math.roundToInt

/**
 * Фоновый Foreground Service адаптивного учебного таймера StudyFlow.
 *
 * Ответственность:
 * - Точный отсчёт времени без накопления дрейфа (опора на [SystemClock.elapsedRealtime]).
 * - Ежесекундное обновление [TimerStateHolder] и постоянного уведомления с прогресс-баром.
 * - Автоматический конечный автомат фаз:
 *   `WORK` -> `CLOSURE` (180 сек) -> `BREAK` (900 или 1200 сек) -> `POST_CHECKIN`.
 * - Фоновая синхронизация фактических минут и счётчика отвлечений с локальной БД Room на [Dispatchers.IO].
 */
class TimerForegroundService : Service() {

    private val serviceSupervisorJob = SupervisorJob()
    private val serviceScope = CoroutineScope(serviceSupervisorJob + Dispatchers.Main.immediate)

    private var timerJob: Job? = null

    private lateinit var notificationManager: NotificationManager
    private lateinit var database: AppDatabase

    override fun onCreate() {
        super.onCreate()
        notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        database = AppDatabase.getInstance(applicationContext)
        ensureNotificationChannels()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START_BLOCK -> handleStartBlock(intent)
            ACTION_PAUSE -> handlePause()
            ACTION_RESUME -> handleResume()
            ACTION_REGISTER_DISTRACTION -> handleRegisterDistraction()
            ACTION_TRIGGER_EARLY_CLOSURE -> handleEarlyClosure()
            ACTION_STOP -> handleStopSession()
            else -> {
                if (TimerStateHolder.state.value.phase == TimerPhase.IDLE) {
                    stopSelf()
                }
            }
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        timerJob?.cancel()
        timerJob = null
        serviceScope.cancel()
        super.onDestroy()
    }

    // ------------------------- Обработчики команд -------------------------

    private fun handleStartBlock(intent: Intent) {
        val blockId = intent.getLongExtra(EXTRA_BLOCK_ID, -1L)
        if (blockId <= 0L) {
            Log.w(TAG, "Запуск отклонён: передан некорректный blockId=$blockId")
            stopSelf()
            return
        }

        val title = intent.getStringExtra(EXTRA_BLOCK_TITLE).orEmpty()
            .ifBlank { "Учебный блок" }
        val tierLevel = intent.getIntExtra(EXTRA_BLOCK_TIER, CognitiveTier.TIER_1.level)
        val tier = CognitiveTier.fromLevel(tierLevel)
        val plannedMinutes = intent.getIntExtra(
            EXTRA_PLANNED_MINUTES,
            RuleEngine.MIN_WORK_DURATION_MINUTES
        )
        val initialDistractions = intent.getIntExtra(EXTRA_INITIAL_DISTRACTIONS, 0)

        TimerStateHolder.startWorkSession(
            blockId = blockId,
            title = title,
            tier = tier,
            plannedWorkMinutes = plannedMinutes,
            initialDistractions = initialDistractions
        )

        promoteToForeground(buildOngoingNotification(TimerStateHolder.state.value))
        startCountdownLoop()
    }

    private fun handlePause() {
        val snapshot = TimerStateHolder.state.value
        if (!snapshot.isRunning || snapshot.phase == TimerPhase.IDLE || snapshot.phase == TimerPhase.POST_CHECKIN) {
            return
        }
        timerJob?.cancel()
        timerJob = null
        TimerStateHolder.setRunning(false)
        updateOngoingNotification(TimerStateHolder.state.value)
    }

    private fun handleResume() {
        val snapshot = TimerStateHolder.state.value
        if (snapshot.isRunning || snapshot.remainingSeconds <= 0) {
            return
        }
        if (snapshot.phase == TimerPhase.IDLE || snapshot.phase == TimerPhase.POST_CHECKIN) {
            return
        }
        TimerStateHolder.setRunning(true)
        promoteToForeground(buildOngoingNotification(TimerStateHolder.state.value))
        startCountdownLoop()
    }

    private fun handleRegisterDistraction() {
        val snapshot = TimerStateHolder.state.value
        if (snapshot.phase != TimerPhase.WORK) return

        TimerStateHolder.registerDistraction()
        val updated = TimerStateHolder.state.value
        updateOngoingNotification(updated)

        val blockId = updated.activeBlockId
        if (blockId != null) {
            serviceScope.launch(Dispatchers.IO) {
                try {
                    database.studyDao().incrementDistractionCount(blockId)
                } catch (e: Exception) {
                    Log.e(TAG, "Ошибка сохранения счётчика отвлечений в БД для блока $blockId", e)
                }
            }
        }
    }

    private fun handleEarlyClosure() {
        val snapshot = TimerStateHolder.state.value
        if (snapshot.phase != TimerPhase.WORK) return

        timerJob?.cancel()
        timerJob = null

        serviceScope.launch {
            persistActualWorkMinutes(snapshot)
            TimerStateHolder.transitionToPhase(
                newPhase = TimerPhase.CLOSURE,
                durationSeconds = RuleEngine.CLOSURE_DURATION_SECONDS,
                isRunning = true
            )
            postPhaseAlertNotification(
                title = "Переход в буфер закрытия (3 мин)",
                body = "Зафиксируйте точку остановки и следующий шаг, чтобы снять остаточное внимание."
            )
            updateOngoingNotification(TimerStateHolder.state.value)
            startCountdownLoop()
        }
    }

    private fun handleStopSession() {
        val snapshot = TimerStateHolder.state.value
        timerJob?.cancel()
        timerJob = null

        serviceScope.launch {
            if (snapshot.phase == TimerPhase.WORK && snapshot.elapsedWorkSeconds > 0) {
                persistActualWorkMinutes(snapshot)
            }
            TimerStateHolder.reset()
            ServiceCompat.stopForeground(this@TimerForegroundService, ServiceCompat.STOP_FOREGROUND_REMOVE)
            notificationManager.cancel(ONGOING_NOTIFICATION_ID)
            stopSelf()
        }
    }

    // ------------------------- Основной цикл таймера -------------------------

    private fun startCountdownLoop() {
        timerJob?.cancel()
        timerJob = serviceScope.launch {
            try {
                while (isActive) {
                    val snapshot = TimerStateHolder.state.value
                    if (!snapshot.isRunning || snapshot.phase == TimerPhase.IDLE || snapshot.phase == TimerPhase.POST_CHECKIN) {
                        break
                    }

                    val phaseEndRealtimeMs = SystemClock.elapsedRealtime() + snapshot.remainingSeconds * 1_000L
                    var lastTickRealtimeMs = SystemClock.elapsedRealtime()

                    while (isActive && TimerStateHolder.state.value.isRunning) {
                        delay(TICK_INTERVAL_MS)

                        val nowRealtimeMs = SystemClock.elapsedRealtime()
                        val remainingMs = (phaseEndRealtimeMs - nowRealtimeMs).coerceAtLeast(0L)
                        val remainingSec = ceil(remainingMs / 1_000.0).toInt()
                        val deltaSec = ((nowRealtimeMs - lastTickRealtimeMs) / 1_000L).toInt().coerceAtLeast(1)
                        lastTickRealtimeMs = nowRealtimeMs

                        TimerStateHolder.updateTick(
                            newRemainingSeconds = remainingSec,
                            elapsedDeltaSeconds = deltaSec
                        )

                        val updatedState = TimerStateHolder.state.value
                        updateOngoingNotification(updatedState)

                        if (remainingSec <= 0) {
                            handlePhaseCompleted(updatedState)
                            break
                        }
                    }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "Неожиданная ошибка в цикле таймера", e)
            }
        }
    }

    /**
     * Конечный автомат переходов по завершении текущей фазы:
     * WORK -> CLOSURE (180 сек) -> BREAK (900 / 1200 сек) -> POST_CHECKIN.
     */
    private suspend fun handlePhaseCompleted(completedState: TimerSnapshot) {
        when (completedState.phase) {
            TimerPhase.WORK -> {
                persistActualWorkMinutes(completedState)
                TimerStateHolder.transitionToPhase(
                    newPhase = TimerPhase.CLOSURE,
                    durationSeconds = RuleEngine.CLOSURE_DURATION_SECONDS,
                    isRunning = true
                )
                postPhaseAlertNotification(
                    title = "Рабочий блок завершён — буфер закрытия (3 мин)",
                    body = "Запишите, на чём вы остановились, чтобы мозг не удерживал задачу в фоне."
                )
                updateOngoingNotification(TimerStateHolder.state.value)
            }

            TimerPhase.CLOSURE -> {
                val breakSeconds = RuleEngine.calculateRecommendedBreakSeconds(
                    plannedWorkMinutes = completedState.plannedWorkMinutes
                )
                TimerStateHolder.transitionToPhase(
                    newPhase = TimerPhase.BREAK,
                    durationSeconds = breakSeconds,
                    isRunning = true
                )
                val breakState = TimerStateHolder.state.value
                val breakMinutes = breakSeconds / 60
                postPhaseAlertNotification(
                    title = "Обязательный отдых ($breakMinutes мин)",
                    body = breakState.breakRecommendation ?: "Сделайте перерыв без экранов."
                )
                updateOngoingNotification(breakState)
            }

            TimerPhase.BREAK -> {
                TimerStateHolder.transitionToPhase(
                    newPhase = TimerPhase.POST_CHECKIN,
                    durationSeconds = 0,
                    isRunning = false
                )
                postPhaseAlertNotification(
                    title = "Перерыв окончен — оцените энергию (1–5)",
                    body = "Откройте StudyFlow для быстрого чек-ина, чтобы адаптировать следующий блок."
                )
                ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
                notificationManager.cancel(ONGOING_NOTIFICATION_ID)
                stopSelf()
            }

            TimerPhase.IDLE,
            TimerPhase.POST_CHECKIN -> Unit
        }
    }

    /**
     * Сохраняет фактически отработанные минуты в Room на [Dispatchers.IO].
     */
    private suspend fun persistActualWorkMinutes(snapshot: TimerSnapshot) {
        val blockId = snapshot.activeBlockId ?: return
        val actualMinutes = (snapshot.elapsedWorkSeconds / 60.0).roundToInt()
            .coerceAtLeast(if (snapshot.elapsedWorkSeconds > 0) 1 else 0)

        withContext(Dispatchers.IO) {
            try {
                database.studyDao().updateActualMinutes(
                    blockId = blockId,
                    actualMinutes = actualMinutes
                )
            } catch (e: Exception) {
                Log.e(TAG, "Ошибка записи actualMinutes=$actualMinutes для блока $blockId", e)
            }
        }
    }

    // ------------------------- Уведомления и Foreground -------------------------

    private fun promoteToForeground(notification: Notification) {
        val foregroundType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
        } else {
            0
        }
        try {
            ServiceCompat.startForeground(
                this,
                ONGOING_NOTIFICATION_ID,
                notification,
                foregroundType
            )
        } catch (e: Exception) {
            Log.e(TAG, "Не удалось перевести сервис в режим Foreground", e)
        }
    }

    private fun ensureNotificationChannels() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return

        val ongoingChannel = NotificationChannel(
            CHANNEL_ONGOING_ID,
            "Активный учебный таймер",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Показывает текущую фазу и обратный отсчёт учебного блока"
            setShowBadge(false)
            lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        }

        val alertsChannel = NotificationChannel(
            CHANNEL_ALERTS_ID,
            "Переключение фаз StudyFlow",
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = "Сигналы о завершении рабочего блока, буфера закрытия и перерыва"
            enableVibration(true)
            lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        }

        notificationManager.createNotificationChannels(listOf(ongoingChannel, alertsChannel))
    }

    private fun buildOngoingNotification(state: TimerSnapshot): Notification {
        val formattedTime = formatSeconds(state.remainingSeconds)
        val statusSuffix = if (state.isRunning) "" else " • Пауза"
        val title = "${state.phase.displayName}: $formattedTime$statusSuffix"

        val contentText = when (state.phase) {
            TimerPhase.WORK -> {
                if (state.earlyClosureRecommended) {
                    "Отвлечений: ${state.distractionCount}. Рекомендуется досрочный буфер закрытия."
                } else {
                    "${state.activeBlockTitle} (${state.activeBlockTier.displayName})"
                }
            }
            TimerPhase.CLOSURE -> "Зафиксируйте точку остановки и следующий микрошаг."
            TimerPhase.BREAK -> state.breakRecommendation ?: "Восстановительный отдых без экранов."
            TimerPhase.POST_CHECKIN -> "Оцените уровень энергии от 1 до 5."
            TimerPhase.IDLE -> "Таймер остановлен."
        }

        val elapsedInPhase = (state.totalPhaseSeconds - state.remainingSeconds).coerceAtLeast(0)

        val builder = NotificationCompat.Builder(this, CHANNEL_ONGOING_ID)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(title)
            .setContentText(contentText)
            .setStyle(NotificationCompat.BigTextStyle().bigText(contentText))
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setSilent(true)
            .setCategory(NotificationCompat.CATEGORY_PROGRESS)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setProgress(state.totalPhaseSeconds, elapsedInPhase, false)

        createAppLaunchPendingIntent()?.let { builder.setContentIntent(it) }

        // Кнопка Пауза / Продолжить
        if (state.isRunning) {
            builder.addAction(
                android.R.drawable.ic_media_pause,
                "Пауза",
                createServiceActionPendingIntent(ACTION_PAUSE, REQ_CODE_PAUSE)
            )
        } else if (state.phase != TimerPhase.IDLE && state.phase != TimerPhase.POST_CHECKIN) {
            builder.addAction(
                android.R.drawable.ic_media_play,
                "Продолжить",
                createServiceActionPendingIntent(ACTION_RESUME, REQ_CODE_RESUME)
            )
        }

        // Контекстная кнопка в фазе WORK: «Мысли блуждают» или «Буфер закрытия»
        if (state.phase == TimerPhase.WORK) {
            if (state.earlyClosureRecommended) {
                builder.addAction(
                    android.R.drawable.ic_menu_save,
                    "В буфер закрытия",
                    createServiceActionPendingIntent(ACTION_TRIGGER_EARLY_CLOSURE, REQ_CODE_CLOSURE)
                )
            } else {
                builder.addAction(
                    android.R.drawable.ic_dialog_info,
                    "Мысли блуждают (${state.distractionCount})",
                    createServiceActionPendingIntent(ACTION_REGISTER_DISTRACTION, REQ_CODE_DISTRACTION)
                )
            }
        }

        builder.addAction(
            android.R.drawable.ic_menu_close_clear_cancel,
            "Стоп",
            createServiceActionPendingIntent(ACTION_STOP, REQ_CODE_STOP)
        )

        return builder.build()
    }

    private fun updateOngoingNotification(state: TimerSnapshot) {
        try {
            notificationManager.notify(ONGOING_NOTIFICATION_ID, buildOngoingNotification(state))
        } catch (e: SecurityException) {
            Log.w(TAG, "Нет разрешения POST_NOTIFICATIONS для обновления уведомления", e)
        }
    }

    private fun postPhaseAlertNotification(title: String, body: String) {
        val builder = NotificationCompat.Builder(this, CHANNEL_ALERTS_ID)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)

        createAppLaunchPendingIntent()?.let { builder.setContentIntent(it) }

        try {
            notificationManager.notify(ALERT_NOTIFICATION_ID, builder.build())
        } catch (e: SecurityException) {
            Log.w(TAG, "Нет разрешения POST_NOTIFICATIONS для отправки сигнала фазы", e)
        }
    }

    private fun createAppLaunchPendingIntent(): PendingIntent? {
        val launchIntent = packageManager.getLaunchIntentForPackage(packageName) ?: return null
        launchIntent.flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        return PendingIntent.getActivity(
            this,
            REQ_CODE_LAUNCH_APP,
            launchIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun createServiceActionPendingIntent(action: String, requestCode: Int): PendingIntent {
        val intent = Intent(this, TimerForegroundService::class.java).apply {
            this.action = action
        }
        return PendingIntent.getService(
            this,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun formatSeconds(totalSeconds: Int): String {
        val safe = totalSeconds.coerceAtLeast(0)
        val minutes = safe / 60
        val seconds = safe % 60
        return String.format(Locale.US, "%02d:%02d", minutes, seconds)
    }

    companion object {
        private const val TAG = "TimerForegroundService"

        private const val CHANNEL_ONGOING_ID = "studyflow_timer_ongoing"
        private const val CHANNEL_ALERTS_ID = "studyflow_phase_alerts"
        private const val ONGOING_NOTIFICATION_ID = 1001
        private const val ALERT_NOTIFICATION_ID = 1002

        private const val TICK_INTERVAL_MS = 1_000L

        private const val REQ_CODE_LAUNCH_APP = 100
        private const val REQ_CODE_PAUSE = 101
        private const val REQ_CODE_RESUME = 102
        private const val REQ_CODE_DISTRACTION = 103
        private const val REQ_CODE_CLOSURE = 104
        private const val REQ_CODE_STOP = 105

        const val ACTION_START_BLOCK = "com.studyflow.app.service.action.START_BLOCK"
        const val ACTION_PAUSE = "com.studyflow.app.service.action.PAUSE"
        const val ACTION_RESUME = "com.studyflow.app.service.action.RESUME"
        const val ACTION_REGISTER_DISTRACTION = "com.studyflow.app.service.action.REGISTER_DISTRACTION"
        const val ACTION_TRIGGER_EARLY_CLOSURE = "com.studyflow.app.service.action.TRIGGER_EARLY_CLOSURE"
        const val ACTION_STOP = "com.studyflow.app.service.action.STOP"

        const val EXTRA_BLOCK_ID = "extra_block_id"
        const val EXTRA_BLOCK_TITLE = "extra_block_title"
        const val EXTRA_BLOCK_TIER = "extra_block_tier"
        const val EXTRA_PLANNED_MINUTES = "extra_planned_minutes"
        const val EXTRA_INITIAL_DISTRACTIONS = "extra_initial_distractions"

        /**
         * Фабричный метод создания Intent для запуска учебного блока в Foreground Service.
         */
        fun createStartBlockIntent(
            context: Context,
            blockId: Long,
            title: String,
            tier: CognitiveTier,
            plannedMinutes: Int,
            initialDistractions: Int = 0
        ): Intent = Intent(context, TimerForegroundService::class.java).apply {
            action = ACTION_START_BLOCK
            putExtra(EXTRA_BLOCK_ID, blockId)
            putExtra(EXTRA_BLOCK_TITLE, title)
            putExtra(EXTRA_BLOCK_TIER, tier.level)
            putExtra(EXTRA_PLANNED_MINUTES, plannedMinutes)
            putExtra(EXTRA_INITIAL_DISTRACTIONS, initialDistractions)
        }

        /**
         * Фабричный метод для отправки управляющей команды уже работающему сервису.
         */
        fun createActionIntent(context: Context, action: String): Intent =
            Intent(context, TimerForegroundService::class.java).apply {
                this.action = action
            }
    }
}
