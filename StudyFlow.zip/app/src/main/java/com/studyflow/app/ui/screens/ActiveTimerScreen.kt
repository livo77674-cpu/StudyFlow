// ПУТЬ: com/studyflow/app/ui/screens/ActiveTimerScreen.kt

package com.studyflow.app.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.studyflow.app.domain.model.TimerPhase
import com.studyflow.app.service.TimerSnapshot
import com.studyflow.app.ui.theme.StudyFlowColors
import com.studyflow.app.ui.theme.accentColor
import com.studyflow.app.ui.theme.containerColor
import kotlinx.coroutines.delay
import java.util.Locale
import kotlin.math.roundToInt

@Composable
fun ActiveTimerScreen(
    snapshot: TimerSnapshot,
    initialClosureNote: String,
    onPause: () -> Unit,
    onResume: () -> Unit,
    onRegisterDistraction: () -> Unit,
    onTriggerEarlyClosure: () -> Unit,
    onStop: () -> Unit,
    onSaveClosureNote: (blockId: Long, note: String) -> Unit,
    onSubmitPostCheckIn: (blockId: Long, energyAfter: Int) -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxSize(),
        color = StudyFlowColors.Background
    ) {
        when (snapshot.phase) {
            TimerPhase.WORK -> WorkPhaseContent(
                snapshot = snapshot,
                onPause = onPause,
                onResume = onResume,
                onRegisterDistraction = onRegisterDistraction,
                onTriggerEarlyClosure = onTriggerEarlyClosure,
                onStop = onStop
            )

            TimerPhase.CLOSURE -> ClosurePhaseContent(
                snapshot = snapshot,
                initialClosureNote = initialClosureNote,
                onSaveClosureNote = onSaveClosureNote
            )

            TimerPhase.BREAK -> BreakPhaseContent(
                snapshot = snapshot
            )

            TimerPhase.POST_CHECKIN -> PostCheckInPhaseContent(
                snapshot = snapshot,
                onSubmitPostCheckIn = onSubmitPostCheckIn,
                onFallbackStop = onStop
            )

            TimerPhase.IDLE -> Unit
        }
    }
}

@Composable
private fun WorkPhaseContent(
    snapshot: TimerSnapshot,
    onPause: () -> Unit,
    onResume: () -> Unit,
    onRegisterDistraction: () -> Unit,
    onTriggerEarlyClosure: () -> Unit,
    onStop: () -> Unit
) {
    var showStopConfirmDialog by rememberSaveable { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 18.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Верхняя плашка: эшелон и название блока
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Surface(
                color = snapshot.activeBlockTier.containerColor(),
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, snapshot.activeBlockTier.accentColor().copy(alpha = 0.5f))
            ) {
                Text(
                    text = "TIER ${snapshot.activeBlockTier.level} · ${snapshot.activeBlockTier.displayName}",
                    style = MaterialTheme.typography.labelLarge,
                    color = snapshot.activeBlockTier.accentColor(),
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                )
            }

            Text(
                text = snapshot.activeBlockTitle.ifBlank { "Фокусный блок" },
                style = MaterialTheme.typography.headlineSmall,
                color = StudyFlowColors.TextPrimary,
                textAlign = TextAlign.Center
            )
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Крупный круговой индикатор обратного отсчёта
        CircularCountdownRing(
            progress = snapshot.progressFraction,
            remainingSeconds = snapshot.remainingSeconds,
            statusLabel = if (snapshot.isRunning) "ФОКУСНАЯ РАБОТА" else "ПАУЗА",
            ringColor = StudyFlowColors.PrimaryOrange,
            ringSize = 270.dp
        )

        Spacer(modifier = Modifier.height(20.dp))

        // Акцентная рекомендация досрочного перехода в CLOSURE при >= 2 отвлечениях
        if (snapshot.earlyClosureRecommended) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = StudyFlowColors.PrimaryOrangeContainer),
                border = BorderStroke(1.dp, StudyFlowColors.PrimaryOrange)
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Warning,
                            contentDescription = null,
                            tint = StudyFlowColors.PrimaryOrangeLight,
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            text = "Снижение концентрации",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = StudyFlowColors.PrimaryOrangeLight
                        )
                    }
                    Text(
                        text = snapshot.earlyClosureMessage
                            ?: "Зафиксировано ${snapshot.distractionCount} отвлечения. Рекомендуется перейти в 3-минутный буфер закрытия.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = StudyFlowColors.TextPrimary
                    )
                    Button(
                        onClick = onTriggerEarlyClosure,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = StudyFlowColors.PrimaryOrange,
                            contentColor = Color(0xFF140A02)
                        )
                    ) {
                        Text(
                            text = "Перейти в буфер закрытия сейчас",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(14.dp))
        }

        // Панель управления фазой WORK
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Кнопка «Мысли блуждают (N)»
            OutlinedButton(
                onClick = onRegisterDistraction,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(
                    width = 1.dp,
                    color = if (snapshot.distractionCount > 0) {
                        StudyFlowColors.Warning
                    } else {
                        StudyFlowColors.SurfaceStroke
                    }
                ),
                colors = ButtonDefaults.outlinedButtonColors(
                    containerColor = StudyFlowColors.Surface,
                    contentColor = if (snapshot.distractionCount > 0) {
                        StudyFlowColors.Warning
                    } else {
                        StudyFlowColors.TextPrimary
                    }
                )
            ) {
                Icon(
                    imageVector = Icons.Rounded.Warning,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Мысли блуждают (${snapshot.distractionCount})",
                    style = MaterialTheme.typography.titleMedium
                )
            }

            // Кнопки «Пауза / Продолжить» и «Стоп»
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Button(
                    onClick = { if (snapshot.isRunning) onPause() else onResume() },
                    modifier = Modifier
                        .weight(1.4f)
                        .height(54.dp),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = StudyFlowColors.PrimaryOrange,
                        contentColor = Color(0xFF140A02)
                    )
                ) {
                    if (snapshot.isRunning) {
                        PauseGlyph(color = Color(0xFF140A02))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Пауза",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Rounded.PlayArrow,
                            contentDescription = null,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Продолжить",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                OutlinedButton(
                    onClick = { showStopConfirmDialog = true },
                    modifier = Modifier
                        .weight(1f)
                        .height(54.dp),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, StudyFlowColors.Danger.copy(alpha = 0.6f)),
                    colors = ButtonDefaults.outlinedButtonColors(
                        containerColor = StudyFlowColors.DangerContainer.copy(alpha = 0.45f),
                        contentColor = StudyFlowColors.Danger
                    )
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Close,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Стоп",
                        style = MaterialTheme.typography.titleMedium
                    )
                }
            }
        }
    }

    if (showStopConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showStopConfirmDialog = false },
            containerColor = StudyFlowColors.Surface,
            titleContentColor = StudyFlowColors.TextPrimary,
            textContentColor = StudyFlowColors.TextSecondary,
            shape = RoundedCornerShape(20.dp),
            title = { Text("Остановить учебный блок?") },
            text = {
                Text(
                    "Фактически отработанные минуты будут сохранены, но вы пропустите буфер закрытия и перерыв."
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showStopConfirmDialog = false
                        onStop()
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = StudyFlowColors.Danger,
                        contentColor = Color.White
                    )
                ) {
                    Text("Остановить")
                }
            },
            dismissButton = {
                TextButton(onClick = { showStopConfirmDialog = false }) {
                    Text("Продолжить работу", color = StudyFlowColors.PrimaryOrangeLight)
                }
            }
        )
    }
}

@Composable
private fun ClosurePhaseContent(
    snapshot: TimerSnapshot,
    initialClosureNote: String,
    onSaveClosureNote: (blockId: Long, note: String) -> Unit
) {
    val blockId = snapshot.activeBlockId
    var noteText by rememberSaveable(blockId) { mutableStateOf(initialClosureNote) }
    var lastSavedNote by remember(blockId) { mutableStateOf(initialClosureNote) }
    val latestNote by rememberUpdatedState(noteText)
    val latestSaveCallback by rememberUpdatedState(onSaveClosureNote)

    // Автосохранение в Room с небольшим дебаунсом
    LaunchedEffect(blockId, noteText) {
        if (blockId != null && noteText != lastSavedNote) {
            delay(450L)
            latestSaveCallback(blockId, noteText)
            lastSavedNote = noteText
        }
    }

    // Гарантированное финальное сохранение при автоматическом переходе в фазу BREAK
    DisposableEffect(blockId) {
        onDispose {
            if (blockId != null && latestNote.isNotBlank()) {
                latestSaveCallback(blockId, latestNote)
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        Surface(
            color = StudyFlowColors.PrimaryOrangeContainer,
            shape = RoundedCornerShape(10.dp),
            border = BorderStroke(1.dp, StudyFlowColors.PrimaryOrange.copy(alpha = 0.5f))
        ) {
            Text(
                text = "БУФЕР ЗАКРЫТИЯ · 3 МИН",
                style = MaterialTheme.typography.labelLarge,
                color = StudyFlowColors.PrimaryOrangeLight,
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
            )
        }

        CircularCountdownRing(
            progress = snapshot.progressFraction,
            remainingSeconds = snapshot.remainingSeconds,
            statusLabel = "СНЯТИЕ ОСТАТОЧНОГО ВНИМАНИЯ",
            ringColor = StudyFlowColors.PrimaryOrangeLight,
            ringSize = 190.dp
        )

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = StudyFlowColors.Surface),
            border = BorderStroke(1.dp, StudyFlowColors.SurfaceStroke)
        ) {
            Column(
                modifier = Modifier.padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "На чём остановился и какой первый микрошаг в следующий раз?",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = StudyFlowColors.TextPrimary
                )

                OutlinedTextField(
                    value = noteText,
                    onValueChange = { noteText = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(160.dp),
                    placeholder = {
                        Text(
                            text = "Например: Разобрал теорему 4.2, завтра начать с решения задачи №7 с третьего шага...",
                            color = StudyFlowColors.TextMuted
                        )
                    },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = StudyFlowColors.PrimaryOrange,
                        unfocusedBorderColor = StudyFlowColors.SurfaceStroke,
                        cursorColor = StudyFlowColors.PrimaryOrange,
                        focusedTextColor = StudyFlowColors.TextPrimary,
                        unfocusedTextColor = StudyFlowColors.TextPrimary
                    )
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    val isSaved = noteText.isNotBlank() && noteText == lastSavedNote
                    Text(
                        text = when {
                            noteText.isBlank() -> "Обязательная заметка (автосохранение)"
                            isSaved -> "Сохранено офлайн ✓"
                            else -> "Сохранение..."
                        },
                        style = MaterialTheme.typography.labelMedium,
                        color = if (isSaved) StudyFlowColors.Success else StudyFlowColors.TextSecondary
                    )

                    if (blockId != null && noteText.isNotBlank() && noteText != lastSavedNote) {
                        TextButton(
                            onClick = {
                                onSaveClosureNote(blockId, noteText)
                                lastSavedNote = noteText
                            },
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Text("Сохранить", color = StudyFlowColors.PrimaryOrangeLight)
                        }
                    }
                }
            }
        }

        Text(
            text = "По окончании 3 минут автоматически начнётся обязательный восстановительный перерыв.",
            style = MaterialTheme.typography.bodyMedium,
            color = StudyFlowColors.TextSecondary,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
private fun BreakPhaseContent(
    snapshot: TimerSnapshot
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 24.dp, vertical = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Surface(
                color = StudyFlowColors.BreakContainer,
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, StudyFlowColors.BreakAccent.copy(alpha = 0.45f))
            ) {
                Text(
                    text = "ОБЯЗАТЕЛЬНЫЙ ОТДЫХ",
                    style = MaterialTheme.typography.labelLarge,
                    color = StudyFlowColors.BreakAccent,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                )
            }
            Text(
                text = "Восстановление внимания",
                style = MaterialTheme.typography.headlineSmall,
                color = StudyFlowColors.TextPrimary
            )
        }

        CircularCountdownRing(
            progress = snapshot.progressFraction,
            remainingSeconds = snapshot.remainingSeconds,
            statusLabel = "ОТЛОЖИТЕ ЭКРАН",
            ringColor = StudyFlowColors.BreakAccent,
            ringSize = 260.dp
        )

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = StudyFlowColors.BreakContainer),
            border = BorderStroke(1.dp, StudyFlowColors.BreakAccent.copy(alpha = 0.35f))
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Info,
                        contentDescription = null,
                        tint = StudyFlowColors.BreakAccent,
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        text = "Рекомендация на перерыв",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = StudyFlowColors.BreakAccentSoft
                    )
                }

                Text(
                    text = snapshot.breakRecommendation
                        ?: "Посмотрите вдаль через окно, попейте воды и пройдитесь без телефона.",
                    style = MaterialTheme.typography.bodyLarge,
                    color = StudyFlowColors.TextPrimary
                )

                Text(
                    text = "Перерыв нельзя пропустить досрочно: мозгу нужно время для консолидации памяти.",
                    style = MaterialTheme.typography.labelMedium,
                    color = StudyFlowColors.TextSecondary
                )
            }
        }
    }
}

@Composable
private fun PostCheckInPhaseContent(
    snapshot: TimerSnapshot,
    onSubmitPostCheckIn: (blockId: Long, energyAfter: Int) -> Unit,
    onFallbackStop: () -> Unit
) {
    var selectedEnergy by rememberSaveable { mutableIntStateOf(0) }
    val energyDescriptors = listOf(
        1 to "Истощён",
        2 to "Устал",
        3 to "Норма",
        4 to "Бодро",
        5 to "Пик"
    )
    val workedMinutes = (snapshot.elapsedWorkSeconds / 60.0).roundToInt()
        .coerceAtLeast(if (snapshot.elapsedWorkSeconds > 0) 1 else 0)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Surface(
                color = StudyFlowColors.PrimaryOrangeContainer,
                shape = RoundedCornerShape(10.dp)
            ) {
                Text(
                    text = "POST-CHECKIN",
                    style = MaterialTheme.typography.labelLarge,
                    color = StudyFlowColors.PrimaryOrangeLight,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                )
            }

            Text(
                text = "Как ваша энергия после блока?",
                style = MaterialTheme.typography.headlineMedium,
                color = StudyFlowColors.TextPrimary,
                textAlign = TextAlign.Center
            )

            Text(
                text = "${snapshot.activeBlockTitle} · Отработано ~$workedMinutes мин",
                style = MaterialTheme.typography.bodyMedium,
                color = StudyFlowColors.TextSecondary,
                textAlign = TextAlign.Center
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        // 5 крупных кнопок оценки энергии (1–5)
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            energyDescriptors.forEach { (level, label) ->
                val isSelected = selectedEnergy == level
                val bgColor = if (isSelected) {
                    StudyFlowColors.PrimaryOrange
                } else {
                    StudyFlowColors.Surface
                }
                val contentColor = if (isSelected) {
                    Color(0xFF140A02)
                } else {
                    StudyFlowColors.TextPrimary
                }

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(60.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(bgColor)
                        .border(
                            width = if (isSelected) 1.5.dp else 1.dp,
                            color = if (isSelected) {
                                StudyFlowColors.PrimaryOrangeLight
                            } else {
                                StudyFlowColors.SurfaceStroke
                            },
                            shape = RoundedCornerShape(16.dp)
                        )
                        .clickable { selectedEnergy = level }
                        .padding(horizontal = 18.dp),
                    contentAlignment = Alignment.CenterStart
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            Text(
                                text = level.toString(),
                                style = MaterialTheme.typography.headlineSmall,
                                fontWeight = FontWeight.Bold,
                                color = contentColor
                            )
                            Text(
                                text = label,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.SemiBold,
                                color = contentColor
                            )
                        }

                        if (isSelected) {
                            Icon(
                                imageVector = Icons.Rounded.Check,
                                contentDescription = null,
                                tint = contentColor
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        Button(
            onClick = {
                val blockId = snapshot.activeBlockId
                if (blockId != null && selectedEnergy in 1..5) {
                    onSubmitPostCheckIn(blockId, selectedEnergy)
                } else {
                    onFallbackStop()
                }
            },
            enabled = selectedEnergy in 1..5,
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp),
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = StudyFlowColors.PrimaryOrange,
                contentColor = Color(0xFF140A02),
                disabledContainerColor = StudyFlowColors.SurfaceElevated,
                disabledContentColor = StudyFlowColors.TextMuted
            )
        ) {
            Text(
                text = "Завершить блок",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
private fun CircularCountdownRing(
    progress: Float,
    remainingSeconds: Int,
    statusLabel: String,
    ringColor: Color,
    ringSize: Dp
) {
    val clampedProgress = progress.coerceIn(0f, 1f)
    val trackColor = StudyFlowColors.SurfaceElevated

    Box(
        modifier = Modifier.size(ringSize),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val strokeWidth = 14.dp.toPx()
            val inset = strokeWidth / 2f
            val arcSize = Size(size.width - strokeWidth, size.height - strokeWidth)
            val topLeft = Offset(inset, inset)

            // Базовая дорожка
            drawArc(
                color = trackColor,
                startAngle = -90f,
                sweepAngle = 360f,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
            )

            // Активный прогресс
            drawArc(
                color = ringColor,
                startAngle = -90f,
                sweepAngle = 360f * clampedProgress,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
            )
        }

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text(
                text = formatTimerSeconds(remainingSeconds),
                style = MaterialTheme.typography.displayLarge,
                color = StudyFlowColors.TextPrimary
            )
            Text(
                text = statusLabel,
                style = MaterialTheme.typography.labelSmall,
                color = StudyFlowColors.TextSecondary,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
private fun PauseGlyph(color: Color) {
    Canvas(modifier = Modifier.size(16.dp)) {
        val barWidth = size.width * 0.28f
        val barHeight = size.height * 0.85f
        val topOffset = (size.height - barHeight) / 2f
        val radius = CornerRadius(2.dp.toPx(), 2.dp.toPx())

        drawRoundRect(
            color = color,
            topLeft = Offset(size.width * 0.14f, topOffset),
            size = Size(barWidth, barHeight),
            cornerRadius = radius
        )
        drawRoundRect(
            color = color,
            topLeft = Offset(size.width * 0.58f, topOffset),
            size = Size(barWidth, barHeight),
            cornerRadius = radius
        )
    }
}

private fun formatTimerSeconds(totalSeconds: Int): String {
    val safe = totalSeconds.coerceAtLeast(0)
    val minutes = safe / 60
    val seconds = safe % 60
    return String.format(Locale.US, "%02d:%02d", minutes, seconds)
}
