// ПУТЬ: com/studyflow/app/data/local/DailyStateEntity.kt

package com.studyflow.app.data.local

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Сущность ежедневного когнитивного состояния пользователя.
 * Одна запись соответствует одному календарному дню в формате ISO-8601 (`YYYY-MM-DD`).
 *
 * @property date Дата в формате `YYYY-MM-DD` (первичный ключ).
 * @property sleepQuality Субъективная оценка качества утреннего сна (1..5).
 * @property tier1LimitMinutes Динамически рассчитанный дневной лимит минут для TIER_1.
 * @property consecutiveWorkDays Количество учебных дней подряд без разгрузочного дня.
 * @property deloadSuggested Флаг, указывающий, что движок правил рекомендовал Deload-день.
 */
@Entity(tableName = "daily_states")
data class DailyStateEntity(
    @PrimaryKey
    @ColumnInfo(name = "date")
    val date: String,

    @ColumnInfo(name = "sleep_quality")
    val sleepQuality: Int,

    @ColumnInfo(name = "tier1_limit_minutes")
    val tier1LimitMinutes: Int,

    @ColumnInfo(name = "consecutive_work_days")
    val consecutiveWorkDays: Int = 0,

    @ColumnInfo(name = "deload_suggested")
    val deloadSuggested: Boolean = false
) {
    companion object {
        const val MIN_SLEEP_QUALITY = 1
        const val MAX_SLEEP_QUALITY = 5
    }

    /**
     * Проверяет корректность диапазона сохранённой оценки сна.
     */
    fun hasValidSleepQuality(): Boolean = sleepQuality in MIN_SLEEP_QUALITY..MAX_SLEEP_QUALITY
}
