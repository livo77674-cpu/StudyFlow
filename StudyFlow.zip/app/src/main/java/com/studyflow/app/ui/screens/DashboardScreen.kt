// ПУТЬ: com/studyflow/app/ui/screens/DashboardScreen.kt

package com.studyflow.app.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.KeyboardArrowUp
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Snackbar
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.studyflow.app.data.local.DailyStateEntity
import com.studyflow.app.data.local.StudyBlockEntity
import com.studyflow.app.domain.engine.EnergyAdaptationAction
import com.studyflow.app.domain.engine.RuleEngine
import com.studyflow.app.domain.model.BlockStatus
import com.studyflow.app.domain.model.CognitiveTier
import com.studyflow.app.ui.theme.StudyFlowColors
import com.studyflow.app.ui.theme.accentColor
import com.studyflow.app.ui.theme.containerColor
import com.studyflow.app.ui.viewmodel.StudyUiState
import kotlin.math.roundToInt

@Composable
fun DashboardScreen(
    uiState: StudyUiState,
    onSaveMorningSleep: (Int) -> Unit,
    onAddBlock: (title: String, tier: CognitiveTier, plannedMinutes: Int) -> Unit,
    onDeleteBlock: (StudyBlockEntity) -> Unit,
    onStartBlock: (block: StudyBlockEntity, energyBefore: Int) -> Unit,
    onApplyEnergyAdaptation: (List<StudyBlockEntity>) -> Unit,
    onDismissSnackbar: () -> Unit
) {
    val snackbarHostState = remember { SnackbarHostState() }
    var showAddBlockDialog by rememberSaveable { mutableStateOf(false) }
    var blockPendingStart by remember { mutableStateOf<StudyBlockEntity?>(null) }
    var eveningSummaryExpanded by rememberSaveable { mutableStateOf(false) }

    LaunchedEffect(uiState.snackbarMessage) {
        val message = uiState.snackbarMessage
        if (!message.isNullOrBlank()) {
            snackbarHostState.showSnackbar(message)
            onDismissSnackbar()
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = StudyFlowColors.Background,
        snackbarHost = {
            SnackbarHost(hostState = snackbarHostState) { data ->
                Snackbar(
                    snackbarData = data,
                    containerColor = StudyFlowColors.SurfaceElevated,
                    contentColor = StudyFlowColors.TextPrimary,
                    actionColor = StudyFlowColors.PrimaryOrange
                )
            }
        },
        floatingActionButton = {
            if (uiState.dailyState != null) {
                FloatingActionButton(
                    onClick = { showAddBlockDialog = true },
                    containerColor = StudyFlowColors.PrimaryOrange,
                    contentColor = Color(0xFF140A02),
                    shape = RoundedCornerShape(18.dp),
                    modifier = Modifier.navigationBarsPadding()
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Add,
                        contentDescription = "Добавить учебный блок"
                    )
                }
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .statusBarsPadding(),
            contentPadding = PaddingValues(
                start = 16.dp,
                end = 16.dp,
                top = 12.dp,
                bottom = 96.dp
            ),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Заголовок экрана
            item(key = "header") {
                DashboardHeader(
                    date = uiState.todayDate,
                    dailyState = uiState.dailyState
                )
            }

            // Утренний чек-ин качества сна (если сегодня ещё не заполнен)
            if (!uiState.isLoading && uiState.dailyState == null) {
                item(key = "morning_sleep_checkin") {
                    MorningSleepCheckInCard(
                        onSaveSleepQuality = onSaveMorningSleep
                    )
                }
            }

            // Верхний блок «Когнитивный бюджет дня»
            item(key = "cognitive_budget") {
                CognitiveBudgetCard(uiState = uiState)
            }

            // Умные баннеры-подсказки от RuleEngine
            if (uiState.deloadEvaluation.isDeloadRecommended) {
                item(key = "banner_deload") {
                    RuleBannerCard(
                        title = "5-й день подряд · Рекомендован Deload",
                        message = uiState.deloadEvaluation.recommendation,
                        accentColor = StudyFlowColors.BreakAccent,
                        containerColor = StudyFlowColors.BreakContainer,
                        isWarning = false
                    )
                }
            }

            if (uiState.tier1Overload.isTier1Blocked && !uiState.deloadEvaluation.isDeloadRecommended) {
                item(key = "banner_tier1_overload") {
                    RuleBannerCard(
                        title = "Лимит TIER_1 исчерпан",
                        message = uiState.tier1Overload.recommendation,
                        accentColor = StudyFlowColors.Danger,
                        containerColor = StudyFlowColors.DangerContainer,
                        isWarning = true
                    )
                }
            }

            if (uiState.energyDropEvaluation.action != EnergyAdaptationAction.CONTINUE_AS_PLANNED) {
                val hasPlannedBlocks = uiState.blocks.any { it.status == BlockStatus.PLANNED }
                val isCritical = uiState.energyDropEvaluation.action ==
                    EnergyAdaptationAction.SHORTEN_DAY_OR_STOP

                item(key = "banner_energy_drop") {
                    RuleBannerCard(
                        title = if (isCritical) {
                            "Критическое падение энергии"
                        } else {
                            "Падение энергии 2 блока подряд"
                        },
                        message = uiState.energyDropEvaluation.recommendation,
                        accentColor = if (isCritical) StudyFlowColors.Danger else StudyFlowColors.Warning,
                        containerColor = if (isCritical) {
                            StudyFlowColors.DangerContainer
                        } else {
                            StudyFlowColors.WarningContainer
                        },
                        isWarning = true,
                        actionLabel = if (hasPlannedBlocks) "Облегчить оставшиеся задачи" else null,
                        onActionClick = if (hasPlannedBlocks) {
                            { onApplyEnergyAdaptation(uiState.blocks) }
                        } else {
                            null
                        }
                    )
                }
            }

            // Заголовок секции блоков
            item(key = "blocks_section_title") {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Учебные блоки сегодня",
                        style = MaterialTheme.typography.titleLarge,
                        color = StudyFlowColors.TextPrimary
                    )
                    Text(
                        text = "${uiState.blocks.count { it.status == BlockStatus.COMPLETED }}/${uiState.blocks.size}",
                        style = MaterialTheme.typography.labelLarge,
                        color = StudyFlowColors.TextSecondary
                    )
                }
            }

            // Пустое состояние или список учебных блоков
            if (uiState.blocks.isEmpty()) {
                item(key = "empty_blocks") {
                    EmptyBlocksCard(
                        canAddBlock = uiState.dailyState != null,
                        onAddClick = { showAddBlockDialog = true }
                    )
                }
            } else {
                items(
                    items = uiState.blocks,
                    key = { it.id }
                ) { block ->
                    StudyBlockCard(
                        block = block,
                        onStartClick = { blockPendingStart = block },
                        onDeleteClick = { onDeleteBlock(block) }
                    )
                }
            }

            // Сворачиваемая карточка «Вечерняя сводка дня»
            item(key = "evening_summary") {
                EveningSummaryCard(
                    uiState = uiState,
                    expanded = eveningSummaryExpanded,
                    onToggleExpanded = { eveningSummaryExpanded = !eveningSummaryExpanded }
                )
            }
        }
    }

    // Диалог создания нового учебного блока
    if (showAddBlockDialog) {
        AddStudyBlockDialog(
            isTier1Blocked = uiState.tier1Overload.isTier1Blocked,
            isDeloadDay = uiState.deloadEvaluation.isDeloadRecommended,
            onDismiss = { showAddBlockDialog = false },
            onConfirm = { title, tier, minutes ->
                onAddBlock(title, tier, minutes)
                showAddBlockDialog = false
            }
        )
    }

    // Быстрый однотаповый диалог энергии (1–5) перед стартом блока
    blockPendingStart?.let { targetBlock ->
        PreStartEnergyDialog(
            block = targetBlock,
            onDismiss = { blockPendingStart = null },
            onSelectEnergyAndStart = { energy ->
                blockPendingStart = null
                onStartBlock(targetBlock, energy)
            }
        )
    }
}

@Composable
private fun DashboardHeader(
    date: String,
    dailyState: DailyStateEntity?
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column {
            Text(
                text = "StudyFlow",
                style = MaterialTheme.typography.headlineMedium,
                color = StudyFlowColors.TextPrimary
            )
            Text(
                text = date,
                style = MaterialTheme.typography.bodyMedium,
                color = StudyFlowColors.TextSecondary
            )
        }

        if (dailyState != null) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                MetricPill(
                    label = "Сон ${dailyState.sleepQuality}/5",
                    accent = if (dailyState.sleepQuality <= RuleEngine.POOR_SLEEP_THRESHOLD) {
                        StudyFlowColors.Warning
                    } else {
                        StudyFlowColors.PrimaryOrangeLight
                    }
                )
                MetricPill(
                    label = "День ${dailyState.consecutiveWorkDays}",
                    accent = if (dailyState.deloadSuggested) {
                        StudyFlowColors.BreakAccent
                    } else {
                        StudyFlowColors.TextSecondary
                    }
                )
            }
        }
    }
}

@Composable
private fun MetricPill(
    label: String,
    accent: Color
) {
    Surface(
        color = StudyFlowColors.Surface,
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, StudyFlowColors.SurfaceStroke)
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            color = accent,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
        )
    }
}

@Composable
private fun MorningSleepCheckInCard(
    onSaveSleepQuality: (Int) -> Unit
) {
    var selectedSleep by rememberSaveable { mutableIntStateOf(4) }
    val previewLimit = RuleEngine.calculateTier1DailyLimit(sleepQuality = selectedSleep)
    val isReduced = selectedSleep <= RuleEngine.POOR_SLEEP_THRESHOLD

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = StudyFlowColors.Surface),
        border = BorderStroke(1.dp, StudyFlowColors.PrimaryOrange.copy(alpha = 0.45f))
    ) {
        Column(
            modifier = Modifier.padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "Утренний чек-ин сна",
                style = MaterialTheme.typography.titleLarge,
                color = StudyFlowColors.TextPrimary
            )
            Text(
                text = "Оцените качество сна от 1 до 5 — это задаст безопасный дневной потолок для тяжёлой работы (TIER_1).",
                style = MaterialTheme.typography.bodyMedium,
                color = StudyFlowColors.TextSecondary
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                (1..5).forEach { score ->
                    val isSelected = selectedSleep == score
                    val bgColor = if (isSelected) {
                        StudyFlowColors.PrimaryOrange
                    } else {
                        StudyFlowColors.SurfaceElevated
                    }
                    val textColor = if (isSelected) {
                        Color(0xFF140A02)
                    } else {
                        StudyFlowColors.TextPrimary
                    }

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(bgColor)
                            .border(
                                width = 1.dp,
                                color = if (isSelected) {
                                    StudyFlowColors.PrimaryOrangeLight
                                } else {
                                    StudyFlowColors.SurfaceStroke
                                },
                                shape = RoundedCornerShape(14.dp)
                            )
                            .clickable { selectedSleep = score },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = score.toString(),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = textColor
                        )
                    }
                }
            }

            Surface(
                color = if (isReduced) {
                    StudyFlowColors.WarningContainer
                } else {
                    StudyFlowColors.SurfaceElevated
                },
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = if (isReduced) {
                        "При сне $selectedSleep/5 лимит TIER_1 будет снижен на 40% — до $previewLimit мин, чтобы избежать когнитивного истощения."
                    } else {
                        "При сне $selectedSleep/5 доступен полный базовый лимит TIER_1 — $previewLimit мин."
                    },
                    style = MaterialTheme.typography.bodyMedium,
                    color = if (isReduced) StudyFlowColors.Warning else StudyFlowColors.TextSecondary,
                    modifier = Modifier.padding(12.dp)
                )
            }

            Button(
                onClick = { onSaveSleepQuality(selectedSleep) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = StudyFlowColors.PrimaryOrange,
                    contentColor = Color(0xFF140A02)
                )
            ) {
                Text(
                    text = "Рассчитать бюджет дня",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
private fun CognitiveBudgetCard(
    uiState: StudyUiState
) {
    val tier1Used = uiState.minutesForTier(CognitiveTier.TIER_1)
    val tier1Limit = uiState.tier1Overload.limitMinutes
    val tier1Progress = when {
        tier1Limit <= 0 -> 1f
        else -> (tier1Used.toFloat() / tier1Limit.toFloat()).coerceIn(0f, 1f)
    }

    val tier2Used = uiState.minutesForTier(CognitiveTier.TIER_2)
    val tier3Used = uiState.minutesForTier(CognitiveTier.TIER_3)
    val softReferenceMinutes = 120f

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = StudyFlowColors.Surface),
        border = BorderStroke(1.dp, StudyFlowColors.SurfaceStroke)
    ) {
        Column(
            modifier = Modifier.padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Когнитивный бюджет дня",
                    style = MaterialTheme.typography.titleLarge,
                    color = StudyFlowColors.TextPrimary
                )
                Text(
                    text = "Всего ${uiState.totalMinutesToday} мин",
                    style = MaterialTheme.typography.labelLarge,
                    color = StudyFlowColors.PrimaryOrangeLight
                )
            }

            // TIER 1 — жёсткий лимит
            TierProgressRow(
                label = "TIER 1 · Тяжёлое (Deliberate Practice)",
                valueText = if (tier1Limit == 0) {
                    "Deload · 0 мин"
                } else {
                    "$tier1Used / $tier1Limit мин"
                },
                progress = tier1Progress,
                barColor = if (uiState.tier1Overload.isTier1Blocked) {
                    StudyFlowColors.Danger
                } else {
                    CognitiveTier.TIER_1.accentColor()
                },
                isLocked = uiState.tier1Overload.isTier1Blocked
            )

            // TIER 2 — практика
            TierProgressRow(
                label = "TIER 2 · Практика (Active Recall)",
                valueText = "$tier2Used мин",
                progress = (tier2Used / softReferenceMinutes).coerceIn(0f, 1f),
                barColor = CognitiveTier.TIER_2.accentColor(),
                isLocked = false
            )

            // TIER 3 — лёгкий обзор
            TierProgressRow(
                label = "TIER 3 · Лёгкий обзор (Worked Examples)",
                valueText = "$tier3Used мин",
                progress = (tier3Used / softReferenceMinutes).coerceIn(0f, 1f),
                barColor = CognitiveTier.TIER_3.accentColor(),
                isLocked = false
            )
        }
    }
}

@Composable
private fun TierProgressRow(
    label: String,
    valueText: String,
    progress: Float,
    barColor: Color,
    isLocked: Boolean
) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.weight(1f)
            ) {
                if (isLocked) {
                    Icon(
                        imageVector = Icons.Rounded.Lock,
                        contentDescription = null,
                        tint = barColor,
                        modifier = Modifier.size(14.dp)
                    )
                }
                Text(
                    text = label,
                    style = MaterialTheme.typography.bodyMedium,
                    color = StudyFlowColors.TextSecondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = valueText,
                style = MaterialTheme.typography.labelLarge,
                color = if (isLocked) barColor else StudyFlowColors.TextPrimary
            )
        }

        LinearProgressIndicator(
            progress = { progress },
            modifier = Modifier
                .fillMaxWidth()
                .height(8.dp)
                .clip(RoundedCornerShape(6.dp)),
            color = barColor,
            trackColor = StudyFlowColors.SurfaceElevated,
            strokeCap = StrokeCap.Round
        )
    }
}

@Composable
private fun RuleBannerCard(
    title: String,
    message: String,
    accentColor: Color,
    containerColor: Color,
    isWarning: Boolean,
    actionLabel: String? = null,
    onActionClick: (() -> Unit)? = null
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = containerColor),
        border = BorderStroke(1.dp, accentColor.copy(alpha = 0.45f))
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = if (isWarning) Icons.Rounded.Warning else Icons.Rounded.Info,
                    contentDescription = null,
                    tint = accentColor,
                    modifier = Modifier.size(18.dp)
                )
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = accentColor
                )
            }

            Text(
                text = message,
                style = MaterialTheme.typography.bodyMedium,
                color = StudyFlowColors.TextPrimary
            )

            if (actionLabel != null && onActionClick != null) {
                OutlinedButton(
                    onClick = onActionClick,
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, accentColor),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = accentColor)
                ) {
                    Text(
                        text = actionLabel,
                        style = MaterialTheme.typography.labelLarge
                    )
                }
            }
        }
    }
}

@Composable
private fun EmptyBlocksCard(
    canAddBlock: Boolean,
    onAddClick: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = StudyFlowColors.Surface),
        border = BorderStroke(1.dp, StudyFlowColors.SurfaceStroke)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(
                text = "План на сегодня пока пуст",
                style = MaterialTheme.typography.titleMedium,
                color = StudyFlowColors.TextPrimary
            )
            Text(
                text = "Добавьте первый фокусный блок длительностью 50–80 минут и выберите когнитивный эшелон.",
                style = MaterialTheme.typography.bodyMedium,
                color = StudyFlowColors.TextSecondary
            )
            if (canAddBlock) {
                Button(
                    onClick = onAddClick,
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = StudyFlowColors.PrimaryOrange,
                        contentColor = Color(0xFF140A02)
                    )
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Add,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Добавить блок")
                }
            }
        }
    }
}

@Composable
private fun StudyBlockCard(
    block: StudyBlockEntity,
    onStartClick: () -> Unit,
    onDeleteClick: () -> Unit
) {
    val tier = block.toCognitiveTier()
    val isCompleted = block.status == BlockStatus.COMPLETED

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isCompleted) {
                StudyFlowColors.Surface.copy(alpha = 0.72f)
            } else {
                StudyFlowColors.Surface
            }
        ),
        border = BorderStroke(
            width = 1.dp,
            color = if (isCompleted) {
                StudyFlowColors.SurfaceStroke.copy(alpha = 0.6f)
            } else {
                StudyFlowColors.SurfaceStroke
            }
        )
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Surface(
                        color = tier.containerColor(),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = "TIER ${tier.level}",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = tier.accentColor(),
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }

                    if (block.status == BlockStatus.DOWNGRADED) {
                        Surface(
                            color = StudyFlowColors.WarningContainer,
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = "Облегчён",
                                style = MaterialTheme.typography.labelSmall,
                                color = StudyFlowColors.Warning,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    if (isCompleted) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.CheckCircle,
                                contentDescription = null,
                                tint = StudyFlowColors.Success,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = "Завершён",
                                style = MaterialTheme.typography.labelSmall,
                                color = StudyFlowColors.Success
                            )
                        }
                    }
                }

                if (!isCompleted) {
                    IconButton(
                        onClick = onDeleteClick,
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Delete,
                            contentDescription = "Удалить блок",
                            tint = StudyFlowColors.TextMuted,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            Text(
                text = block.title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                color = if (isCompleted) {
                    StudyFlowColors.TextSecondary
                } else {
                    StudyFlowColors.TextPrimary
                }
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    val timeInfo = if (isCompleted) {
                        "Факт: ${block.actualMinutes} мин (план ${block.plannedMinutes} мин)"
                    } else {
                        "План: ${block.plannedMinutes} мин · ${tier.displayName}"
                    }
                    Text(
                        text = timeInfo,
                        style = MaterialTheme.typography.bodyMedium,
                        color = StudyFlowColors.TextSecondary
                    )

                    if (block.energyBefore != null || block.energyAfter != null || block.distractionCount > 0) {
                        val details = buildList {
                            if (block.energyBefore != null && block.energyAfter != null) {
                                add("Энергия: ${block.energyBefore} → ${block.energyAfter}")
                            } else if (block.energyBefore != null) {
                                add("Энергия до: ${block.energyBefore}")
                            }
                            if (block.distractionCount > 0) {
                                add("Отвлечений: ${block.distractionCount}")
                            }
                        }.joinToString(" · ")

                        Text(
                            text = details,
                            style = MaterialTheme.typography.labelMedium,
                            color = StudyFlowColors.TextMuted
                        )
                    }
                }

                if (!isCompleted) {
                    Button(
                        onClick = onStartClick,
                        shape = RoundedCornerShape(12.dp),
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = StudyFlowColors.PrimaryOrange,
                            contentColor = Color(0xFF140A02)
                        )
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.PlayArrow,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Старт",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun EveningSummaryCard(
    uiState: StudyUiState,
    expanded: Boolean,
    onToggleExpanded: () -> Unit
) {
    val completedBlocks = uiState.blocks.filter { it.energyAfter != null || it.status == BlockStatus.COMPLETED }
    val closureNotes = uiState.blocks.filter { it.closureNote.isNotBlank() }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = StudyFlowColors.Surface),
        border = BorderStroke(1.dp, StudyFlowColors.SurfaceStroke)
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable(onClick = onToggleExpanded)
                    .padding(18.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Вечерняя сводка дня",
                        style = MaterialTheme.typography.titleLarge,
                        color = StudyFlowColors.TextPrimary
                    )
                    Text(
                        text = "Итоги по эшелонам, динамика энергии и заметки закрытия (${closureNotes.size})",
                        style = MaterialTheme.typography.bodyMedium,
                        color = StudyFlowColors.TextSecondary
                    )
                }
                Icon(
                    imageVector = if (expanded) {
                        Icons.Rounded.KeyboardArrowUp
                    } else {
                        Icons.Rounded.KeyboardArrowDown
                    },
                    contentDescription = if (expanded) "Свернуть" else "Развернуть",
                    tint = StudyFlowColors.PrimaryOrangeLight
                )
            }

            AnimatedVisibility(
                visible = expanded,
                enter = expandVertically() + fadeIn(),
                exit = shrinkVertically() + fadeOut()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(start = 18.dp, end = 18.dp, bottom = 18.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    HorizontalDivider(color = StudyFlowColors.SurfaceStroke)

                    // Суммарное время по эшелонам
                    Text(
                        text = "Суммарное время по эшелонам",
                        style = MaterialTheme.typography.labelLarge,
                        color = StudyFlowColors.TextSecondary
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        CognitiveTier.entries.forEach { tier ->
                            Surface(
                                modifier = Modifier.weight(1f),
                                color = StudyFlowColors.SurfaceElevated,
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Column(
                                    modifier = Modifier.padding(10.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Text(
                                        text = "TIER ${tier.level}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = tier.accentColor()
                                    )
                                    Text(
                                        text = "${uiState.minutesForTier(tier)} мин",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = StudyFlowColors.TextPrimary
                                    )
                                }
                            }
                        }
                    }

                    // Динамика энергии
                    Text(
                        text = "Динамика энергии",
                        style = MaterialTheme.typography.labelLarge,
                        color = StudyFlowColors.TextSecondary
                    )
                    if (completedBlocks.isEmpty()) {
                        Text(
                            text = "Пока нет завершённых блоков с оценкой энергии.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = StudyFlowColors.TextMuted
                        )
                    } else {
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            completedBlocks.forEachIndexed { index, block ->
                                val beforeText = block.energyBefore?.toString() ?: "—"
                                val afterText = block.energyAfter?.toString() ?: "—"
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "${index + 1}. ${block.title}",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = StudyFlowColors.TextPrimary,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.weight(1f)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "$beforeText → $afterText / 5",
                                        style = MaterialTheme.typography.labelLarge,
                                        color = StudyFlowColors.PrimaryOrangeLight
                                    )
                                }
                            }
                            Text(
                                text = uiState.energyDropEvaluation.recommendation,
                                style = MaterialTheme.typography.bodyMedium,
                                color = StudyFlowColors.TextSecondary,
                                modifier = Modifier.padding(top = 4.dp)
                            )
                        }
                    }

                    // Заметки из 3-минутного буфера закрытия
                    Text(
                        text = "Точки остановки на завтра (буфер закрытия)",
                        style = MaterialTheme.typography.labelLarge,
                        color = StudyFlowColors.TextSecondary
                    )
                    if (closureNotes.isEmpty()) {
                        Text(
                            text = "Заметки появятся после прохождения 3-минутного буфера закрытия.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = StudyFlowColors.TextMuted
                        )
                    } else {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            closureNotes.forEach { block ->
                                Surface(
                                    color = StudyFlowColors.SurfaceElevated,
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(
                                        modifier = Modifier.padding(12.dp),
                                        verticalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Text(
                                            text = block.title,
                                            style = MaterialTheme.typography.labelLarge,
                                            color = block.toCognitiveTier().accentColor()
                                        )
                                        Text(
                                            text = block.closureNote,
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = StudyFlowColors.TextPrimary
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AddStudyBlockDialog(
    isTier1Blocked: Boolean,
    isDeloadDay: Boolean,
    onDismiss: () -> Unit,
    onConfirm: (title: String, tier: CognitiveTier, plannedMinutes: Int) -> Unit
) {
    var title by rememberSaveable { mutableStateOf("") }
    var selectedTier by remember {
        mutableStateOf(
            if (isTier1Blocked || isDeloadDay) CognitiveTier.TIER_2 else CognitiveTier.TIER_1
        )
    }
    var durationSlider by rememberSaveable { mutableFloatStateOf(60f) }
    val plannedMinutes = durationSlider.roundToInt().coerceIn(
        RuleEngine.MIN_WORK_DURATION_MINUTES,
        RuleEngine.MAX_WORK_DURATION_MINUTES
    )
    val breakMinutes = RuleEngine.calculateRecommendedBreakSeconds(plannedMinutes) / 60

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = StudyFlowColors.Surface,
        titleContentColor = StudyFlowColors.TextPrimary,
        textContentColor = StudyFlowColors.TextSecondary,
        shape = RoundedCornerShape(22.dp),
        title = {
            Text(
                text = "Новый учебный блок",
                style = MaterialTheme.typography.headlineSmall
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Название задачи или темы") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = StudyFlowColors.PrimaryOrange,
                        unfocusedBorderColor = StudyFlowColors.SurfaceStroke,
                        focusedLabelColor = StudyFlowColors.PrimaryOrangeLight,
                        cursorColor = StudyFlowColors.PrimaryOrange,
                        focusedTextColor = StudyFlowColors.TextPrimary,
                        unfocusedTextColor = StudyFlowColors.TextPrimary
                    )
                )

                Text(
                    text = "Когнитивный эшелон",
                    style = MaterialTheme.typography.labelLarge,
                    color = StudyFlowColors.TextPrimary
                )

                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    CognitiveTier.entries.forEach { tier ->
                        val isSelected = selectedTier == tier
                        val isTierLocked = tier == CognitiveTier.TIER_1 && (isTier1Blocked || isDeloadDay)

                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .clickable { selectedTier = tier },
                            color = if (isSelected) {
                                tier.containerColor()
                            } else {
                                StudyFlowColors.SurfaceElevated
                            },
                            border = BorderStroke(
                                width = if (isSelected) 1.5.dp else 1.dp,
                                color = if (isSelected) tier.accentColor() else StudyFlowColors.SurfaceStroke
                            )
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    if (isTierLocked) {
                                        Icon(
                                            imageVector = Icons.Rounded.Lock,
                                            contentDescription = null,
                                            tint = StudyFlowColors.Danger,
                                            modifier = Modifier.size(14.dp)
                                        )
                                    }
                                    Text(
                                        text = "TIER ${tier.level} · ${tier.displayName}",
                                        style = MaterialTheme.typography.labelLarge,
                                        color = if (isSelected) {
                                            tier.accentColor()
                                        } else {
                                            StudyFlowColors.TextPrimary
                                        }
                                    )
                                }
                                Text(
                                    text = if (isTierLocked) {
                                        "Лимит TIER_1 закрыт — при сохранении блок автоматически перейдёт в TIER_2."
                                    } else {
                                        tier.methodology
                                    },
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (isTierLocked) {
                                        StudyFlowColors.Warning
                                    } else {
                                        StudyFlowColors.TextSecondary
                                    }
                                )
                            }
                        }
                    }
                }

                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Длительность работы",
                            style = MaterialTheme.typography.labelLarge,
                            color = StudyFlowColors.TextPrimary
                        )
                        Text(
                            text = "$plannedMinutes мин (отдых $breakMinutes мин)",
                            style = MaterialTheme.typography.labelLarge,
                            color = StudyFlowColors.PrimaryOrangeLight
                        )
                    }
                    Slider(
                        value = durationSlider,
                        onValueChange = { durationSlider = it },
                        valueRange = RuleEngine.MIN_WORK_DURATION_MINUTES.toFloat()..
                            RuleEngine.MAX_WORK_DURATION_MINUTES.toFloat(),
                        steps = 5,
                        colors = SliderDefaults.colors(
                            thumbColor = StudyFlowColors.PrimaryOrange,
                            activeTrackColor = StudyFlowColors.PrimaryOrange,
                            inactiveTrackColor = StudyFlowColors.SurfaceElevated
                        )
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirm(title, selectedTier, plannedMinutes) },
                enabled = title.trim().isNotEmpty(),
                colors = ButtonDefaults.buttonColors(
                    containerColor = StudyFlowColors.PrimaryOrange,
                    contentColor = Color(0xFF140A02)
                )
            ) {
                Text("Добавить")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Отмена", color = StudyFlowColors.TextSecondary)
            }
        }
    )
}

@Composable
private fun PreStartEnergyDialog(
    block: StudyBlockEntity,
    onDismiss: () -> Unit,
    onSelectEnergyAndStart: (Int) -> Unit
) {
    val labels = listOf("1 · Низкая", "2 · Устал", "3 · Норма", "4 · Бодро", "5 · Пик")

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = StudyFlowColors.Surface,
        titleContentColor = StudyFlowColors.TextPrimary,
        shape = RoundedCornerShape(22.dp),
        title = {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = "Энергия перед стартом",
                    style = MaterialTheme.typography.headlineSmall
                )
                Text(
                    text = "${block.title} · ${block.plannedMinutes} мин",
                    style = MaterialTheme.typography.bodyMedium,
                    color = StudyFlowColors.TextSecondary
                )
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "Выберите текущий уровень в один тап, чтобы сразу запустить фокусный блок:",
                    style = MaterialTheme.typography.bodyMedium,
                    color = StudyFlowColors.TextSecondary
                )
                (1..5).forEach { level ->
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { onSelectEnergyAndStart(level) },
                        color = StudyFlowColors.SurfaceElevated,
                        border = BorderStroke(1.dp, StudyFlowColors.SurfaceStroke)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = labels[level - 1],
                                style = MaterialTheme.typography.titleMedium,
                                color = StudyFlowColors.TextPrimary
                            )
                            Box(
                                modifier = Modifier
                                    .size(28.dp)
                                    .clip(CircleShape)
                                    .background(StudyFlowColors.PrimaryOrangeContainer),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.PlayArrow,
                                    contentDescription = null,
                                    tint = StudyFlowColors.PrimaryOrange,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Отмена", color = StudyFlowColors.TextSecondary)
            }
        }
    )
}
